﻿var Show_Style=;
var Image_=new Array();
var Pics="";
var Links="";
var Titles="";
var Alts="";
var Apic=Pics.split('|');
var ALink=Links.split('|');
var ATitle=Titles.split('|');
var AAlts=Alts.split('|');
var Show_Text=;
for(i=0;i<Apic.length;i++)
  {
   Image_.src = Apic[i]; 
  }


