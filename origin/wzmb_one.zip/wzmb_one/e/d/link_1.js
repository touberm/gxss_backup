﻿
document.write("<select onChange=Link_Open(this.options[this.selectedIndex].value,'link')><option value=''>fsdf</option><option value='http://www.baidu.com'>sdf</option></select>");